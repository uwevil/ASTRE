extern void activateAperiodicServer();
