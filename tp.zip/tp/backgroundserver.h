extern void *runBackgroundServer (void *t);
