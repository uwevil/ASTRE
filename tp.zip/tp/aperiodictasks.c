#include "tasks.h"

#define MAXAPERIODICTASKS 32

TaskInfo aperiodicTaskTable[MAXAPERIODICTASKS];
int lastAperiodicTask;
