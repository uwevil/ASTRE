extern void *runPollingServer (void *t);
