#include "events.h"

void activateAperiodicServer(){
  produceEventTable();
}
