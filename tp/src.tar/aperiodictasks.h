#ifndef APERIODICTASKS_H
#define APERIODICTASKS_H

#include "tasks.h"

extern TaskInfo aperiodicTaskTable[];
extern int lastAperiodicTask;

#endif
